package SitemaDePagamentoMultiplataforma;

public abstract class PagamentoFactory {
    public abstract Pagamento criarPagamento();
}
