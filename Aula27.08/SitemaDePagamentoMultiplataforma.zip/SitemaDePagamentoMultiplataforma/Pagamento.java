package SitemaDePagamentoMultiplataforma;

public interface Pagamento {
    String processarPagamento(double valor);
}
